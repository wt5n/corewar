/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ksenaida <ksenaida@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/11 20:14:11 by ksenaida          #+#    #+#             */
/*   Updated: 2021/02/11 20:51:37 by ksenaida         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/asm.h"

void				read_name(t_chempion *ch, char *line)
{
	int i;

	i = 0;
	while (line[i] != '\0' && line[i] != '"')
	{
		ch->comment[ch->i] = line[i];
		i++;
		ch->i++;
	}
	if (line[i] == '"')
	{
		while (ch->i < COMMENT_LENGTH)
		{
			ch->comment[ch->i] = 0;
			ch->i++;
		}
		ch->i = 0;
	}
	else
	{
		ch->comment[ch->i] = '\n';
		ch->i++;
	}
}

void				read_comment(t_chempion *ch, char *line)
{
	int n;

	n = 0;
	while (line[n] != '\0' && line[n] != '"')
	{
		ch->name[ch->n] = line[n];
		n++;
		ch->n++;
	}
	if (line[n] == '"')
	{
		while (ch->n < PROG_NAME_LENGTH)
		{
			ch->name[ch->n] = 0;
			ch->n++;
		}
		ch->n = 0;
	}
	else
	{
		ch->name[ch->n] = '\n';
		ch->n++;
	}
}

int					free_and_return(char *line, int k)
{
	if (k != -1)
		ft_printf("number = %d   line = %s\n", k, line);
	free(line);
	return (-1);
}

int					tmpt(int tmp)
{
	if (tmp < 0)
		return (-1);
	return (1);
}

int					read_line(int fd, t_chempion *ch, t_new_st_label **label, \
		t_op_strukt **op)
{
	char			*line;
	int				k;
	int				probel;
	int				tmp;

	k = 0;
	while ((tmp = get_next_line(fd, &line)) > 0)
	{
		if (ch->i > COMMENT_LENGTH || ch->n > PROG_NAME_LENGTH)
			return (free_and_return(line, -1));
		if (ch->i != 0)
			read_name(ch, line);
		else if (ch->n != 0)
			read_comment(ch, line);
		else
		{
			k++;
			if ((probel = prop_probel(line)) != -3)
				if (pars_one(line, ch, label, op) < 0)
					return (free_and_return(line, k));
		}
		free(line);
	}
	return (tmpt(tmp));
}
