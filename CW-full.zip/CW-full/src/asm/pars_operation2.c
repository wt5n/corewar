/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pars_operation2.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ksenaida <ksenaida@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/11 19:34:05 by heantoni          #+#    #+#             */
/*   Updated: 2021/02/11 21:15:15 by ksenaida         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/asm.h"

int			analiz_registr(char *srez, t_op_strukt **op)
{
	int		k;
	int		probel;

	probel = 0;
	while (srez[probel] == '\t' || srez[probel] == '\r' || \
	srez[probel] == '\f' || srez[probel] == '\v' || srez[probel] == ' ')
		probel++;
	if (srez[probel] == 'r')
	{
		if ((k = ft_atoi(&srez[probel + 1])) >= 0 && k < 100)
			(*op)->size += T_REG;
		else
			return (-1);
	}
	else if (srez[probel] == DIRECT_CHAR)
	{
		if (g_op_tab[(*op)->name].size == 0)
			(*op)->size += T_DIR * 2;
		else
			(*op)->size += T_DIR;
	}
	else
		(*op)->size += 2;
	return (1);
}

void		pars_register2(char *str, t_op_strukt **op)
{
	if (kol_sim(str, COMMENT_CHAR) != -1)
		str[kol_sim(str, COMMENT_CHAR)] = '\0';
	if (kol_sim(str, ALT_COMMENT_CHAR) != -1)
		str[kol_sim(str, ALT_COMMENT_CHAR)] = '\0';
	(*op)->stroca = ft_strdup(str);
}

int			pars_register3(char *str, t_op_strukt **op)
{
	int		tecyhee;

	if (((tecyhee = kol_sim_not(str, ' ')) < 0) || \
		(simvol(&str[tecyhee], SEPARATOR_CHAR) > g_op_tab[(*op)->name].arg))
		return (-1);
	return (tecyhee);
}

int			pars_register(char *str, t_op_strukt **op, int n)
{
	int		tecyhee;
	char	*srez;

	pars_register2(str, op);
	while (n >= 0)
	{
		if ((tecyhee = pars_register3(str, op)) < 0)
			return (-1);
		if ((n = kol_sim(&str[tecyhee], SEPARATOR_CHAR)) >= 0)
		{
			srez = cut_one(&str[tecyhee], SEPARATOR_CHAR, 0);
			tecyhee += (n + 1);
			str = str + tecyhee;
		}
		else
			srez = cut_one(&str[tecyhee], '\0', 0);
		if (analiz_registr(srez, op) < 0)
		{
			free(srez);
			return (-1);
		}
		free(srez);
	}
	return (1);
}
