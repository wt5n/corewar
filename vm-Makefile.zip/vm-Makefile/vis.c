#include "inc/vm.h"

void	ft_fprint_hex(unsigned char c, FILE *out)
{
    char *base = "0123456789abcdef";
    fprintf(out, "%c", base[c / 16]);
    fprintf(out, "%c", base[c % 16]);
}

void	ft_print_memory_to_file(const void *addr, size_t size, FILE *out)
{
    size_t i;
    size_t j;

    unsigned  char *p;

    i = 0;
    p = (unsigned char*)addr;
    while (i < size)
    {
        j = 0;
        while (j < 64 && i + j < size)
        {
            ft_fprint_hex(p[i + j], out);
            fprintf(out, " ");
            j++;
        }
        fprintf(out, "\n");
        i += 64;
    }
}

int sdl_show()
{
    int a = -1;
    const int WIDTH = 800, HEIGHT = 600;

    SDL_Init( SDL_INIT_EVERYTHING );

    SDL_Window *window = SDL_CreateWindow( "Hello SDL World", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WIDTH, HEIGHT, SDL_WINDOW_ALLOW_HIGHDPI );

    // Check that the window was successfully created
    if ( NULL == window )
    {
        return (1);
    }

    SDL_Event windowEvent;

    while ( ++a < 1 )
    {
        if ( SDL_PollEvent( &windowEvent ) )
        {
            if ( SDL_QUIT == windowEvent.type )
            {
                break;
            }
        }
    }

    SDL_DestroyWindow( window );
    SDL_Quit( );

    return EXIT_SUCCESS;
}

void    visualiser(t_cw *cw)
{
    FILE *out;
    if (!(out = fopen("out.txt", "w+")))
    {
        ft_printf("Не удалось создать файл");
        return;
    }
    // открыть файл удалось
    ft_print_memory_to_file(cw, 4096, out);      // требуемые действия над данными
    fclose(out);
    sdl_show();
 }


